/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Message;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author slaya
 */
public class Message implements Serializable {
private ArrayList<Result> container;
private int code;
public Message(int code){
this.code = code;
}

public Message(int code, ArrayList<Result> container){
    this.code = code;
this.container = container;
}

public Message(int code, Result result){
this.code = code;
container.add(result);
}

public int getCode(){
return code;
}

public ArrayList<Result> getContents(){
return container;
}
}
