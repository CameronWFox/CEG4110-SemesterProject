/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package awsdriver;

import java.awt.Image;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import Message.*;
//import static sun.rmi.transport.TransportConstants.Ping;

/**
 *
 * @author slaya
 */
public class AWSDriver {
private ArrayList<Socket> clients;
private ServerSocket server;
    /**
     * @param args the command line arguments
     */
    public AWSDriver(){
        try{
        clients = new ArrayList<Socket>();
        server = new ServerSocket(1100);
            while(true){
           System.out.println("Awaiting connection...");
           Socket acceptor = server.accept();
           System.out.println("Connection made!");
           ObjectInputStream ois = new ObjectInputStream(acceptor.getInputStream());
           ObjectOutputStream oos = new ObjectOutputStream(acceptor.getOutputStream());
           Message m = (Message) ois.readObject();
           interpret(m);
           oos.writeObject(m);
            }
        
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    public void interpret(Message m){
        switch(m.getCode()){
                case 0: System.out.println("Test");
    }
    }
    
    public void testConnection(int index){
        try{
    Socket destination = clients.get(index);
    System.out.println("Pinging " + destination.getInetAddress().getHostName() + " with [32 bytes] of data:");
    if(destination.isConnected()){
        System.out.println("We are connected!");
    }else{
        System.out.println("Please check connection...");
    }
        }catch(Exception e){
            System.out.println("Something went wrong!");
        }
    }
}







