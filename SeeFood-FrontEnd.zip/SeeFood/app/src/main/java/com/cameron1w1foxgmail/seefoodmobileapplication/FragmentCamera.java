package com.cameron1w1foxgmail.seefoodmobileapplication;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import static android.support.v4.provider.FontsContractCompat.FontRequestCallback.RESULT_OK;

public class FragmentCamera extends Fragment {

    static final int REQUEST_IMAGE_CAPTURE = 1;

    private Button photo_button;
    private ImageView photo_image_view;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View cameraView = inflater.inflate(R.layout.fragment_camera, container, false);

        photo_button = (Button) cameraView.findViewById(R.id.take_photo_button);
        photo_image_view = (ImageView) cameraView.findViewById(R.id.image_photo_view);

        photo_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        return cameraView;
    }
}
