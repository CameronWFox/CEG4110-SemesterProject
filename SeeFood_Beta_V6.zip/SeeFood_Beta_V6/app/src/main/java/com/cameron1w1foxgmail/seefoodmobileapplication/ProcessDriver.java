package com.cameron1w1foxgmail.seefoodmobileapplication;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import android.graphics.Bitmap;
import android.util.Log;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import Message.Message;
import Message.Result;
import java.util.ArrayList;
import java.util.Base64;

public class ProcessDriver {

        private static DataRegulator dr;
        private static AWSCommunicator ac;

        public ProcessDriver(){
            DataRegulator dr = new DataRegulator();
            try {
                ac = new AWSCommunicator();
            }catch(Exception e){
                System.out.println("Please check your connection.");
            }
        }

        public static void processAll(){
            ArrayList<Result> toProcess = dr.getToProcess();
            ArrayList<Result> processed = new ArrayList<Result>() ;
            dr.wipeCompleted();
            try {
                if(toProcess.size() == 0){
                    throw new Exception("There is nothing to process");
                }
               processed = AWSCommunicator.interpret(toProcess);
                dr.addCompleted(processed);
            }catch(Exception e){
                System.out.println("There was an error in your request");
                return;
            }
            //**
            //**
            //KENDALL, WORK WITH THE FRONT END TO MAKE THIS MEHTOD WHAT THEY NEED
            //**
            //**
            for(int i = 0; i != processed.size(); i++){
            System.out.println(processed.get(i).toString());
            }
        }




        public static void createNewResult(String name)
        {
            Result r = new Result(name);
            dr.addCreated(r);
        }

        public static void createReadyResult(String name,Bitmap image){
            byte[] imageBytes = bitmapToBytes(image);
            Result result = new Result(name, imageBytes);
            dr.addToProcess(result);
        }

        public static byte[] bitmapToBytes(Bitmap image){
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            image.compress(Bitmap.CompressFormat.PNG, 100, baos);
            byte[] imageBytes = baos.toByteArray();
            byte[] newImageBytes = Base64.getEncoder().encode(imageBytes);
            return newImageBytes;
        }

        public static void addimage(String name, byte[] img) {
            ArrayList<Result> created = dr.getCreated();
            for (int i = 0; i != created.size(); i++) {
                if (created.get(i).getName() == name) {
                    Result temp = created.get(i);
                    temp.setImage(img);
                    dr.addToProcess(temp);
                    return;
                }
            }
        }

        public static void addCompletedResult(Result r) {
            dr.addCompleted(r);
        }

        public static void displayResults()
        {

        }
    }


