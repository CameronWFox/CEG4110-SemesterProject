package com.cameron1w1foxgmail.seefoodmobileapplication;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class NavigationDrawer extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
//MenuView.ItemView camera;

    //layouts
    private DrawerLayout drawerLayout;
    private DrawerLayout mDrawerLayout;

    //To capture image
    static final int REQUEST_IMAGE_CAPTURE = 1;

    static final int SELECT_IMAGE = 1234;

    static final int PIC_CROP = 1;

    //Used to saved image
    private Context thisCtx;
    private String pFolder = "/seefood";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation_drawer);

        StrictMode.ThreadPolicy policy = new
                StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        builder.detectFileUriExposure();

//        camera = (MenuView.ItemView) findViewById(navigation_drawer_camera);
        mDrawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.navigation_drawer_view);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,
                drawerLayout, toolbar,
                R.string.open_navigation_drawer, R.string.close_navigation_drawer);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        //set the navigation view to current context.
        navigationView.setNavigationItemSelectedListener(this);
    }



    //Close navigation view
    @Override
    public void onBackPressed() {

        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    //Used to select buttons from navigation view
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.navigation_drawer_camera:
//                Toast.makeText(getApplicationContext(),"camera",Toast.LENGTH_LONG).show();
                //Requires the following permisson in the manifest:
                //<uses-permission android:name="android.permission.CAMERA"> </uses-permission>
//                Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
                break;
            case R.id.navigation_drawer_gallery:
//                Toast.makeText(getApplicationContext(),"gallery",Toast.LENGTH_LONG).show();
                Intent intent2 = new Intent();
                intent2.setType("image/*");
                intent2.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent2, "Select Picture"),SELECT_IMAGE);
//                Intent intent2 = new Intent();
//                intent2.setType("image/*");
//                intent2.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
//                intent2.setAction(Intent.ACTION_GET_CONTENT);
//                startActivityForResult(Intent.createChooser(intent2,"Select Picture"), 1);
                break;
            case R.id.navigation_drawer_settings:
                try {
                    Intent cropIntent = new Intent("com.android.camera.action.CROP");
                    // indicate image type and Uri
//                    cropIntent.setDataAndType(picUri, "image/*");
                    // set crop properties here
                    cropIntent.putExtra("crop", true);
                    // indicate aspect of desired crop
                    cropIntent.putExtra("aspectX", 1);
                    cropIntent.putExtra("aspectY", 1);
                    // indicate output X and Y
                    cropIntent.putExtra("outputX", 128);
                    cropIntent.putExtra("outputY", 128);
                    // retrieve data on return
                    cropIntent.putExtra("return-data", true);
                    // start the activity - we handle returning in onActivityResult
                    startActivityForResult(cropIntent, PIC_CROP);
                }
                // respond to users whose devices do not support the crop action
                catch (ActivityNotFoundException anfe) {
                    // display an error message
                    String errorMessage = "Whoops - your device doesn't support the crop action!";
                    Toast toast = Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT);
                    toast.show();
                }
                break;
            case R.id.navigation_drawer_send:
//                Toast.makeText(getApplicationContext(),"send",Toast.LENGTH_LONG).show();
                break;
            case R.id.navigation_drawer_share:
//                Toast.makeText(getApplicationContext(),"share",Toast.LENGTH_LONG).show();
                break;
            case R.id.navigation_drawer_delete:
//                Toast.makeText(getApplicationContext(),"delete",Toast.LENGTH_LONG).show();
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
    // Return image and do something with the image. (Not finished as of now)
    @Override
    protected  void onActivityResult(int requestCode,int ResultCode,Intent data){
        if (requestCode == REQUEST_IMAGE_CAPTURE && ResultCode == RESULT_OK){
            Bundle extras = data.getExtras();
            //stored photo
            Bitmap photo = (Bitmap) extras.get("data");
            saveImage(this,photo);
            Log.d("myTag", "End of onActivityResult.");

        }
    }

    //Save image to phone storage.
    public void saveImage(Context ctx, Bitmap image) {
        thisCtx = ctx;
        String filePath = Environment.getExternalStorageDirectory().getAbsolutePath();
        SimpleDateFormat dtFormat = new SimpleDateFormat("HH:mm:ss");
        //Creates name of pic base on date.
        Calendar calendar = Calendar.getInstance();
        String dt = dtFormat.format(calendar.getTime());
        Log.d("myTag", filePath + pFolder);
        File dir = new File(filePath + pFolder);
        //If dir does not exist lets make it.
        if (!dir.exists()) {
            Log.d("myTag", "Making dir.");
            dir.mkdir();
        }
        File file = new File(dir, dt + ".jpg");
        try {
            FileOutputStream os = new FileOutputStream(file);
            image.compress(Bitmap.CompressFormat.JPEG, 100, os);
            os.flush();
            os.close();
        } catch (Exception e) {

        }

    }

}
