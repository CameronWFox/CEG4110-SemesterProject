/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package awsdriver;

import java.awt.Image;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import Message.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Base64;
import java.util.List;
import java.util.Scanner;
import javax.imageio.ImageIO;
import seefood.SeeFood;
import static seefood.SeeFood.encodeImage;
//import static sun.rmi.transport.TransportConstants.Ping;

/**
 *
 * @author slaya
 */
public class AWSDriver {

    private ServerSocket server;
    private File homeDir;
    private String storageDir = "/home/ubuntu/Storage/";

    /**
     * @param args the command line arguments
     */
    public AWSDriver() {//This thread should ideally run forever
        try {
            server = new ServerSocket(1100);
            homeDir = new File("/pastResults");
            if (!homeDir.exists()) {
                homeDir.mkdir();
            }
            while (true) {
                System.out.println("Awaiting connection...");
                Socket acceptor = server.accept();
                System.out.println("Connection made!");
                ObjectInputStream ois = new ObjectInputStream(acceptor.getInputStream());
                ObjectOutputStream oos = new ObjectOutputStream(acceptor.getOutputStream());
                Message m = (Message) ois.readObject();
                m = interpret(m);
                //System.out.println("Returning " + m.getContents().size() + " results.");
                oos.writeObject(m);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Message interpret(Message m) {
        switch (m.getCode()) {
            case 0:
                System.out.println("Test");
                return m;
            case 1:
                return getResults(m);
            case 2:
                return getAllResults(m);
            default:
                return new Message(5);
        }
    }

    private Message getResults(Message m) {//In this case, m should contain a name and image
        ArrayList<Result> toProcess = m.getContents();
        ArrayList<Result> toReturn = new ArrayList<Result>();

        try {
            for (int i = 0; i != toProcess.size(); i++) {
                toReturn.add(interpretResult(toProcess.get(i)));
            }
            return m; //CHANGE THIS
        } catch (Exception e) {
            return new Message(5);
        }

    }

    private Message getAllResults(Message m) {//This method needs to read all results that are currently stored in the Storage area
        Message returnMessage = new Message(2);
        ArrayList<Result> pastResults = new ArrayList<Result>();
        ArrayList<File> imageList = searchDir(storageDir,".pic" );
        ArrayList<File> textList = searchDir(storageDir, ".txt");
        System.out.println("images: " + imageList.size() + " text: " + textList.size());
        try{
            
            
        if(imageList.size() == textList.size()){
        for(int i = 0; i != imageList.size(); i++){
           Result temp = new Result(imageList.get(i).getPath().substring(imageList.get(i).getPath().length() - 8));
           temp.setImage(fileToBytes(imageList.get(i)));
           temp = interpretResultFile(textList.get(i),temp);
           pastResults.add(temp);
        }
        
        
        }else{
         returnMessage.setCode(3);
         System.out.println("Please fix the storage directory!");
        }
        }catch(Exception e){
          returnMessage.setCode(3);
         System.out.println("Exception Caught");
         e.printStackTrace();
        }
        System.out.println("Returning a message with " + pastResults.size() + " results.");
        returnMessage.setContents(pastResults);
        return returnMessage;
    }

    private static ArrayList<File> searchDir(String directoryPath, String ext) {
        File directory = new File(directoryPath);   
        File[] fileList = directory.listFiles();
        ArrayList<File> toReturn = new ArrayList<File>();
        for(File file : fileList){
            System.out.println(file.getPath());
            if(file.isDirectory()){
               ArrayList<File> returnedFromRecurs = searchDir(file.getPath(), ext); 
               for(File files : returnedFromRecurs){
                 toReturn.add(files);
               }
            }else if(file.getPath().substring((file.getPath().length() - ext.length())).equals(ext)){
                toReturn.add(file);
            }else{
                
            }
        }
        
        return toReturn;
    }

    private Result interpretResult(Result pre) {
        try {
            //Create the process
            Process p;
            String command = "python find_food.py ";//This is the command that will run seefood. It will need a path to the image appended
            //Place the image somewhere the interpreter can find it
            String name = pre.getName();
            byte[] image = pre.getImage();
            // BufferedImage img = new BufferedImage(image.getHeight(null), image.getWidth(null), BufferedImage.TYPE_INT_ARGB);
            // Graphics g = img.getGraphics();
            // g.drawImage(img, image.getHeight(null), image.getWidth(null), null);
            // g.dispose();
            if (name == "" || image == null) {
                return pre;
            } else {
                String temp = ("/home/ubuntu/Storage/" + name + "/");
                //Create directory for the Result
                File directory = new File(temp);
                if (directory.exists()) {

                } else {
                    directory.mkdir();
                }
                System.out.println("Directory made");
                //Make image file for the result
                String destination = temp + "/" + name + ".pic";
                writeImage(destination, image);
                System.out.println("Image Written");
                //Initiate find_food, passing it the path of the image
                p = Runtime.getRuntime().exec(command + temp + "/" + name + ".pic\n");
                //Collect the results and store them in a text file in the location
                System.out.println("Process Created");
                BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));

                //BufferedReader input = new BufferedReader(new InputStreamReader(p.getErrorStream()));
                System.out.println("Streams made");
                // Scanner input = new Scanner(stdInput);
                String output = "";
                String miniString = "";
                while ((miniString = input.readLine()) != null) {
                    System.out.println(miniString);
                    output += miniString;
                }
                Scanner input2 = new Scanner(output);
                System.out.println("Output:" + output);
                //Add the boolean and confidence values to the result you were given

                pre.setConfidence(interpretConfidence(output.substring(output.indexOf("["), output.indexOf("]") + 1)));
                pre.setIsFood(interpretIsFood(output.substring((output.indexOf("Result: ")), output.length())));
                //Write the results to a file in the picture's directory
                BufferedWriter resultLog = new BufferedWriter(new FileWriter(temp + name + ".txt"));
                String toWrite = pre.isFood() + "\n" + pre.getConfidence() + "\n" + name;
                resultLog.write(toWrite);
                resultLog.flush();
                resultLog.close();
                //Return the Result
            }
        } catch (Exception e) {
            System.out.println("Error interacting with find_food.py");
            e.printStackTrace();
        }

        return pre; //CHANGE THIS
    }

    private double interpretConfidence(String line) {
        line = line.substring(2, line.length()); //removes starting brackets
        line = line.substring(0, line.length() - 2);//removes ending brackets
        Scanner input = new Scanner(line);
        double num1 = input.nextDouble();
        double num2 = input.nextDouble();
        if ((num1 > num2) && (num2 != 0)) {
            return Math.pow(num1 / num2,2);
        } else {
            return Math.pow(num2 / num1,2);
        }
    }

    private boolean interpretIsFood(String line) {
        if (line.contains("Result: No food here... :(")) {
            return false;
        } else {
            return true;
        }
    }
    
    private Result interpretResultFile(File file, Result result) throws Exception{
        Scanner input = new Scanner(file);
        result.setIsFood(Boolean.getBoolean(input.nextLine()));
        result.setConfidence(Double.parseDouble(input.nextLine()));
        input.close();
        return result;
    }

    public boolean writeImage(String filePath, byte[] imageDataString) throws Exception {
        byte[] imageByteArray = SeeFood.decodeImage(imageDataString);
        FileOutputStream imageOutFile = new FileOutputStream(filePath);
        imageOutFile.write(imageByteArray);
        imageOutFile.close();
        return true;
    }

    public static byte[] decodeImage(byte[] imageDataString) {
        return Base64.getDecoder().decode(imageDataString);
    }

    public static byte[] fileToBytes(File file) throws IOException {
        byte[] aux = new byte[5];
        try {
            FileInputStream imageInFile = new FileInputStream(file);
            byte imageData[] = new byte[(int) file.length()];
            imageInFile.read(imageData);
            byte[] imageDataString = encodeImage(imageData);
            imageInFile.close();
            return imageDataString;
        } catch (Exception e) {
            System.out.println("oops!");
        }
        return aux;
    }
}
