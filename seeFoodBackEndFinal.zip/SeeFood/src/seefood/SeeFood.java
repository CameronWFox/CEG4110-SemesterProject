/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seefood;

import Message.Message;
import Message.Result;
import awsdriver.AWSDriver;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Window;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.util.Base64;
/**
 *
 * @author slaya
 */
public class SeeFood {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        System.out.println("1: Server");
        System.out.println("2: Client");
        System.out.println("What is this running on?");
        Scanner input = new Scanner(System.in);
        int choice = input.nextInt();
        if (choice == 1) {
            AWSDriver ad = new AWSDriver();
        } else {
            AWSCommunicator ac = new AWSCommunicator();
            File file = new File("C:\\Users\\slaya\\Pictures\\Pictures\\html\\hotdog20.jpg");
            byte[] theImage = readyForTransfer(file);
            Result result = new Result("hotdogCloseup.png", theImage);
            ArrayList<Result> toSend = new ArrayList<Result>();
            toSend.add(result);
            System.out.println(ac.interpret(toSend).get(0));
  //          System.out.println(ac.requestPastResults().get(1));
        }
    }
    
   public static byte[] readyForTransfer(File file) throws IOException {
       byte[] aux = new byte[5];
		try {
			FileInputStream imageInFile = new FileInputStream(file);
			byte imageData[] = new byte[(int)file.length()];
			imageInFile.read(imageData);
			byte[] imageDataString = encodeImage(imageData);
			imageInFile.close();
                        return imageDataString;
                }catch (Exception e){
                  System.out.println("oops!");
                }
                return aux;
   }
	
	public static byte[] encodeImage(byte[] imageByteArray){		
		return Base64.getEncoder().encode(imageByteArray);		
	}
	public static byte[] decodeImage(byte[] imageDataString) {		
		return Base64.getDecoder().decode(imageDataString);
	}


}
