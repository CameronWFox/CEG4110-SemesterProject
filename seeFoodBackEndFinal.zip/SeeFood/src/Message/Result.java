/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Message;

import java.awt.Image;
import java.io.Serializable;
import javax.swing.ImageIcon;

/**
 *
 * @author slaya
 */
public class Result implements Serializable{
    private String name;
    private byte[] img;
    private boolean isFood;
    private double confidence;
    public Result(String name, byte[] img, boolean isFood, double confidence){
        this.name = name;
        this.img = img;
        this.isFood = isFood;
        this.confidence = confidence;
    }
    public Result(String name,byte[] img){
        this.name = name;
        this.img = img;
        isFood = false;
        confidence = 0;
    }
    public Result(String name){
        this.name = name;
        isFood = false;
        confidence = 0;
    }
    
    public String getName(){
        return name;
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public byte[] getImage(){
        return img;
    }
    
    public void setImage(byte[] img){
        this.img = img;
    }
    
    public boolean isFood(){
        return isFood;
    }
    
    public void setIsFood(boolean result){
        this.isFood = result;
    }
    
    public double getConfidence(){
        return confidence;
    }
    
    public void setConfidence(double confidence){
        this.confidence = confidence;
    }
    
    @Override
    public String toString(){
      String rs = name + " has determined to be " + isFood + " when it comes to being food with a confidence of " + confidence;
      return rs;
    }
}
