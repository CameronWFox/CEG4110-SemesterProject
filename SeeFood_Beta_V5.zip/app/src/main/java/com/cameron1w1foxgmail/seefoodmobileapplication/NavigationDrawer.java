package com.cameron1w1foxgmail.seefoodmobileapplication;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
//import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Base64;

import Message.Result;

public class NavigationDrawer extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
//MenuView.ItemView camera
    ImageView iView;
    //layouts
    private DrawerLayout drawerLayout;
    private DrawerLayout mDrawerLayout;
    private Uri imageToUploadUri;

    //To capture image
    static final int REQUEST_IMAGE_CAPTURE = 1;

    static final int SELECT_IMAGE = 1234;

    static final int SELECT_IMAGE_CROP = 1234;

    static final int PIC_CROP = 1;

    //Used to saved image
    private Context thisCtx;
    private String pFolder = "/seefood";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation_drawer);

        StrictMode.ThreadPolicy policy = new
                StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        builder.detectFileUriExposure();

//        camera = (MenuView.ItemView) findViewById(navigation_drawer_camera);
        mDrawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.navigation_drawer_view);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        iView = (ImageView) findViewById(R.id.iView);
        setSupportActionBar(toolbar);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,
                drawerLayout, toolbar,
                R.string.open_navigation_drawer, R.string.close_navigation_drawer);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        //set the navigation view to current context.
        navigationView.setNavigationItemSelectedListener(this);
    }



    //Close navigation view
    @Override
    public void onBackPressed() {

        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    //Used to select buttons from navigation view
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.navigation_drawer_camera:
//                Toast.makeText(getApplicationContext(),"camera",Toast.LENGTH_LONG).show();
                //Requires the following permisson in the manifest:
                //<uses-permission android:name="android.permission.CAMERA"> </uses-permission>
//                Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
//                Intent chooserIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                File f = new File(Environment.getExternalStorageDirectory(), "POST_IMAGE.jpg");
//                chooserIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
//                imageToUploadUri = Uri.fromFile(f);
//                startActivityForResult(chooserIntent, REQUEST_IMAGE_CAPTURE);
                break;
            case R.id.navigation_drawer_gallery:
//
//                Toast.makeText(getApplicationContext(),"gallery",Toast.LENGTH_LONG).show();
//                Intent i = new Intent();
//                i.setType("image/*");
//                i.setAction(Intent.ACTION_GET_CONTENT);
//                startActivityForResult(Intent.createChooser(intent2, "Select Picture"),SELECT_IMAGE);
                Intent i = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                startActivityForResult(i, SELECT_IMAGE);
                break;
            case R.id.navigation_drawer_crop:
                Intent i2 = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                startActivityForResult(i2, SELECT_IMAGE_CROP);
//                try {
//                    Intent cropIntent = new Intent("com.android.camera.action.CROP");
//                    // indicate image type and Uri
//                    cropIntent.setDataAndType(picUri, "image/*");
//                    // set crop properties here
//                    cropIntent.putExtra("crop", true);
//                    // indicate aspect of desired crop
//                    cropIntent.putExtra("aspectX", 1);
//                    cropIntent.putExtra("aspectY", 1);
//                    // indicate output X and Y
//                    cropIntent.putExtra("outputX", 128);
//                    cropIntent.putExtra("outputY", 128);
//                    // retrieve data on return
//                    cropIntent.putExtra("return-data", true);
//                    // start the activity - we handle returning in onActivityResult
//                    startActivityForResult(cropIntent, PIC_CROP);
//                }
//                // respond to users whose devices do not support the crop action
//                catch (ActivityNotFoundException anfe) {
//                    // display an error message
//                    String errorMessage = "Whoops - your device doesn't support the crop action!";
//                    Toast toast = Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT);
//                    toast.show();
//                }
                break;
            case R.id.navigation_drawer_send:
//                Toast.makeText(getApplicationContext(),"send",Toast.LENGTH_LONG).show();
                break;
            case R.id.navigation_drawer_share:
//                Toast.makeText(getApplicationContext(),"share",Toast.LENGTH_LONG).show();
                break;
            case R.id.navigation_drawer_clear:
//                Toast.makeText(getApplicationContext(),"delete",Toast.LENGTH_LONG).show();
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
    // Return image and do something with the image. (Not finished as of now)
    @Override
    protected  void onActivityResult(int requestCode,int ResultCode,Intent data){
        if (requestCode == REQUEST_IMAGE_CAPTURE && ResultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            //stored photo
            Bitmap photo = (Bitmap) extras.get("data");
            try {
                saveImage(this, photo);
            } catch (IOException e) {
                e.printStackTrace();
            }
            iView.setImageBitmap(photo);
            ProcessDriver.createReadyResult(SystemClock.currentThreadTimeMillis()+ "",photo);
            ProcessDriver.processAll();
            try {
                Result temp = DataRegulator.getCompleted().get(0);
                Toast.makeText(getApplicationContext(), temp.toString(), Toast.LENGTH_LONG).show();
            }catch(Exception e){

            }
//            AWSCommunicator ac = null;
//            try {
//                ac = new AWSCommunicator();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//            ByteArrayOutputStream baos = new ByteArrayOutputStream();
//            photo.compress(Bitmap.CompressFormat.JPEG, 100, baos);
//            byte[] imageBytes = baos.toByteArray();
//            Result result = new Result("hot.png", imageBytes);
//            ArrayList<Result> toSend = new ArrayList<Result>();
//            toSend.add(result);
//            try {
//                System.out.println(ac.interpret(toSend).get(0));
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            Log.d("myTag", "End of onActivityResult.");
//            Toast.makeText(getApplicationContext(),result.toString(),Toast.LENGTH_LONG).show();
//            String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);

        }
        if (requestCode == SELECT_IMAGE && ResultCode == RESULT_OK) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();

//            ImageView imageView = (ImageView) findViewById(R.id.imgView);
            iView.setImageBitmap(BitmapFactory.decodeFile(picturePath));
//            try {
//                saveImage(this, photo);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            Toast toast = Toast.makeText(this,"GALLERY SELECTED", Toast.LENGTH_SHORT);
            //iView.setImageBitmap(photo);
        }

        if (requestCode == PIC_CROP && ResultCode == RESULT_OK) {
            if (data != null) {
                // get the returned data
                Bundle extras = data.getExtras();
                // get the cropped bitmap
                Bitmap selectedBitmap = extras.getParcelable("data");

                try {
                    saveImage(this, selectedBitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                iView.setImageBitmap(selectedBitmap);
            }
        }
        if (requestCode == SELECT_IMAGE_CROP && ResultCode == RESULT_OK) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();

            try {
                Intent cropIntent = new Intent("com.android.camera.action.CROP");
                // indicate image type and Uri
                cropIntent.setDataAndType(selectedImage, "image/*");
                // set crop properties here
                cropIntent.putExtra("crop", true);
                // indicate aspect of desired crop
                cropIntent.putExtra("aspectX", 1);
                cropIntent.putExtra("aspectY", 1);
                // indicate output X and Y
                cropIntent.putExtra("outputX", 128);
                cropIntent.putExtra("outputY", 128);
                // retrieve data on return
                cropIntent.putExtra("return-data", true);
                // start the activity - we handle returning in onActivityResult
                startActivityForResult(cropIntent, PIC_CROP);
            }
            // respond to users whose devices do not support the crop action
            catch (ActivityNotFoundException anfe) {
                // display an error message
                String errorMessage = "Whoops - your device doesn't support the crop action!";
                Toast toast = Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT);
                toast.show();
            }
        }




//            AWSCommunicator ac = null;
//            try {
//                ac = new AWSCommunicator();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//            ByteArrayOutputStream baos = new ByteArrayOutputStream();
//            photo.compress(Bitmap.CompressFormat.JPEG, 100, baos);
//            byte[] imageBytes = baos.toByteArray();
//            Result result = new Result("hot.png", imageBytes);
//            ArrayList<Result> toSend = new ArrayList<Result>();
//            toSend.add(result);
//            try {
//                System.out.println(ac.interpret(toSend).get(0));
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            Log.d("myTag", "End of onActivityResult.");
//            Toast.makeText(getApplicationContext(),result.toString(),Toast.LENGTH_LONG).show();
//            String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);


    }

    //Save image to phone storage.
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void saveImage(Context ctx, Bitmap image) throws IOException {
        thisCtx = ctx;
        String filePath = Environment.getExternalStorageDirectory().getAbsolutePath();
        SimpleDateFormat dtFormat = new SimpleDateFormat("HH:mm:ss");
        //Creates name of pic base on date.
        Calendar calendar = Calendar.getInstance();
        String dt = dtFormat.format(calendar.getTime());
        Log.d("myTag", filePath + pFolder);
        File dir = new File(filePath + pFolder);
        //If dir does not exist lets make it.
        if (!dir.exists()) {
            Log.d("myTag", "Making dir.");
            dir.mkdir();
        }
        File file = new File(dir, dt + ".jpg");
        try {
            FileOutputStream os = new FileOutputStream(file);
            image.compress(Bitmap.CompressFormat.JPEG, 100, os);
            os.flush();
            os.close();
        } catch (Exception e) {

        }
//        readyForTransfer(file);

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static byte[] readyForTransfer(File file) throws IOException {
        byte[] aux = new byte[5];
        try {
            FileInputStream imageInFile = new FileInputStream(file);
            byte imageData[] = new byte[(int)file.length()];
            imageInFile.read(imageData);
            byte[] imageDataString = encodeImage(imageData);
            imageInFile.close();
            return imageDataString;
        }catch (Exception e){
            System.out.println("oops!");
        }
        return aux;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static byte[] encodeImage(byte[] imageByteArray){
        return Base64.getEncoder().encode(imageByteArray);
//        Base64.encod(byte[],0);


    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static byte[] decodeImage(byte[] imageDataString) {
        return Base64.getDecoder().decode(imageDataString);
    }

}
