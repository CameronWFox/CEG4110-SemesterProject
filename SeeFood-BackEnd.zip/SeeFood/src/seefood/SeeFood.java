/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seefood;

import awsdriver.AWSDriver;
import java.util.Scanner;

/**
 *
 * @author slaya
 */
public class SeeFood {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
    System.out.println("1: Server");
    System.out.println("2: Client");
    System.out.println("What is this running on?");
    Scanner input = new Scanner(System.in);
    int choice = input.nextInt();
    if(choice == 1){
        AWSDriver ad = new AWSDriver();
    } else{
        AWSCommunicator ac = new AWSCommunicator();
    }
    }
    
}
