/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Message;

import java.awt.Image;

/**
 *
 * @author slaya
 */
public class Result{
    private String name;
    private Image img;
    private boolean isFood;
    private double confidence;
    public Result(String name, Image img, boolean isFood, double confidence){
        this.name = name;
        this.img = img;
        this.isFood = isFood;
        this.confidence = confidence;
    }
    public Result(String name){
        this.name = name;
        isFood = false;
        confidence = 0;
    }
    @Override
    public String toString(){
      String rs = name + " has determined to be " + isFood + " when it comes to being food with a confidence of " + confidence;
      return rs;
    }
}
