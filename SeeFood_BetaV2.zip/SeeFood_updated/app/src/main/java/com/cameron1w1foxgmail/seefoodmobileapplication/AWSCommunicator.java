package com.cameron1w1foxgmail.seefoodmobileapplication;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import Message.Message;
import Message.Result;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author slaya
 */
public class AWSCommunicator {
    Socket server;
    Socket s;

    public AWSCommunicator() throws Exception{//Only one of these should be created per Process Driver
        initializeConnection();
    }

    private void initializeConnection() throws Exception{
        Message test = new Message(0);
        server = new Socket("18.219.205.24",1100);
        System.out.println("Attempting to make a connection");
//Attempt to send an object to the server
        for(int i=0; i != 30; i++){
            try{
                ObjectOutputStream oos = new ObjectOutputStream(server.getOutputStream());
                oos.writeObject(test);
                oos.flush();
            }catch(Exception e){
                System.out.print(".");
            }

//Wait to receive that object back
            try{
                ObjectInputStream ois = new ObjectInputStream(server.getInputStream());
                Message received = (Message)ois.readObject();
                System.out.println(received.getCode());
                ois.close();
            }catch(Exception e){
                //System.out.println("Error: No object returned from the server");
            }
        }
    }

    public ArrayList<Result> interpret(ArrayList<Result> ar) throws IOException{
        Message msg = new Message(1, ar);
        Message returned = new Message(1);
        server = new Socket("18.219.205.24",1100);
        System.out.println("Attempting to make a connection");
//Attempt to send an object to the server
        for(int i=0; i != 30; i++){
            try{
                ObjectOutputStream oos = new ObjectOutputStream(server.getOutputStream());
                oos.writeObject(msg);
                oos.flush();
            }catch(Exception e){
                System.out.print(".");
            }

//Wait to receive that object back
            try{
                ObjectInputStream ois = new ObjectInputStream(server.getInputStream());
                returned = (Message)ois.readObject();
                System.out.println(returned.getCode());
                ois.close();
            }catch(Exception e){
                //System.out.println("Error: No object returned from the server");
            }
        }
        return returned.getContents();
    }


}
