Group 7:
Cameron Fox, Jared Murphy, Taylor Maddox, Kendall Jefferson

Application Name: SeeFood

Our zip file is organized into two sections. The first section contains the server side of the application which includes the following file names: Message.java, Result.java, AWSCommunicator.java, ProcessDriver.java, and DataRegulator.java.The second section includes the client side of the application which include the following file names: NavigationDrawer.java and MainActivity.java. 

The link to our Github repository is: 
CEG4110-SemesterProject/SeeFood_Production_V1.zip