package com.cameron1w1foxgmail.seefoodmobileapplication;

import java.util.ArrayList;

import Message.Result;

public class DataRegulator {
    private static ArrayList<Result> created;
    private static ArrayList<Result> toProcess;
    private static ArrayList<Result> completed;

    public DataRegulator(){
        created = new ArrayList<Result>();
        toProcess = new ArrayList<Result>();
        completed = new ArrayList<Result>();
    }
    public static void addCreated(Result result){
        created.add(result);
    }
    public static void addToProcess(Result result){
        toProcess.add(result);
    }
    public static void addCompleted(Result result) {
        completed.add(result);
    }
    public static void addCompleted(ArrayList<Result> results) {
        for(int i = 0; i!=results.size(); i++) {
            completed.add(results.get(i));
        }
    }
    public static void wipeCreated(){
        ArrayList<Result> wiped = new ArrayList<Result>();
        created = wiped;
    }
    public static void wipeToProcess(){
        ArrayList<Result> wiped = new ArrayList<Result>();
        toProcess = wiped;
    }
    public static void wipeCompleted(){
      completed = new ArrayList<Result>();
    }
    public static ArrayList<Result> getCreated(){
        return created;
    }
    public static ArrayList<Result> getToProcess(){
        return toProcess;
    }
    public static ArrayList<Result> getCompleted(){
        return completed;
    }
}
